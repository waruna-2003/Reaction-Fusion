======================================================================
  REACTIONFUSION: FACEBOOK SINHALA SENTIMENT AI EXTENSION
======================================================================

HOW TO INSTALL & TEST IN GOOGLE CHROME / MICROSOFT EDGE:

1. EXTRACT THIS ZIP ARCHIVE:
   - Extract the contents of this ZIP file to a folder on your computer
     (e.g., C:\ReactionFusion-Extension or ~/ReactionFusion-Extension).

2. OPEN EXTENSION MANAGER IN YOUR BROWSER:
   - In Google Chrome: Open a new tab and go to:  chrome://extensions/
   - In Microsoft Edge: Open a new tab and go to: edge://extensions/

3. ENABLE DEVELOPER MODE:
   - Toggle the "Developer mode" switch ON (in the top-right corner).

4. LOAD THE EXTENSION:
   - Click the "Load unpacked" button (top-left).
   - Select the folder where you extracted these files (the folder containing manifest.json).
   - You will see the "ReactionFusion: Facebook Sinhala Sentiment AI" card appear!

5. CONFIGURE BACKEND API SERVER:
   - Click the ReactionFusion icon in your browser toolbar.
   - By default, it connects to: http://127.0.0.1:8000
   - If testing with a remote or hosted server, type your server URL in the
     "Backend API Server" box and click "Save".
   - Verify that the status badge shows "API Online" (green).

6. TEST ON FACEBOOK:
   - Go to https://www.facebook.com
   - Scroll to any post with Sinhala comments.
   - The "Audience Pulse" badge will automatically appear over the post,
     analyzing the post's comments fused with the post's reaction distribution!

======================================================================
